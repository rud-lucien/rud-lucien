# ModernaSCOPE

## Repo for the 2023-2034 Moderna SCOPE team at Olin College of Engineering